extern const string NULL = "";
extern const string INT_MAX = 2147483647;
extern const string INT_MIN = -2147483648;
extern const string UINT_MAX = 4294967295;
extern const string UINT_MIN = 0;
extern const string CE7B_SELECTIF = "$system$selectIF^%~";
extern const string SIF = CE7B_SELECTIF;
extern const string true = "1";
extern const string false = "";
CEAPI InoreCase NotesStart<Notes> = "WINAPI Who Start";
CEAPI InoreCase NotesEnd<Notes> = "WINAPI Who End";
CEAPI extern const string author__ = "WINAPI Who #pragam @author";
CEAPI extern const string runtime__ = "WINAPI Who pthread_detach(timeable)";
CEAPI extern const string Directory__ = "WINAPI Who & when_create(check_path,GetDirectory)";
extern const string originColor = "original";
 